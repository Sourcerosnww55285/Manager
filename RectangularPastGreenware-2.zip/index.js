// Discord Connected
const { Client, GatewayIntentBits, Collection , EmbedBuilder } = require('discord.js.js')
const fs = require('fs')
// DotEnv
require('dotenv').config();
// Mongoose
const Mongoose = require('mongoose')

// Client Connected
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences
    ]
})

// Handler
client.Command = new Collection()
client.Prefix = '?'
fs.readdirSync(`${process.cwd()}/Handler/`).forEach((Handler) => {
    require(`${process.cwd()}/Handler/${Handler}`)(client)
})

// Ready 
client.on('ready', () => {
    console.log('Client Is Ready', client.user.username)
    client.user.setStatus('dnd')
    client.user.setActivity('Manager Relax')
})


// Monngose Connect
Mongoose.connect(mongoose).then(() => {
    console.log('Database Is Connected')
}).catch((err) => {
    console.log('Database Filed Conneted', err)
})

// Client Login
client.login(token)