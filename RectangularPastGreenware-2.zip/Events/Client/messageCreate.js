"use strict"
const { Collection } = require('discord.js')

/**
 * 
 * @param { import ('discord.js').Client } Client 
 * @param { import ('discord.js').Message } Message 
 */
module.exports = async(Client, Message) => {
    if (!Message.content.startsWith(Client.Prefix) || Message.author.bot) return;
    const Args = Message.content.slice(Client.Prefix.length).trim().split(/ +/)
    const Command = Args.shift().toLowerCase()
    const Cmds = await Client.Command.get(Command) || await Client.Command.find((Cmd) => Cmd.aliases && Cmd.aliases.includes(Command))
    if (!Cmds) return;
    Cmds.run(Client, Message, Args)
}