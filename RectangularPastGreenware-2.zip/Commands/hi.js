module.exports = {
    name: "test"



    run: async( Client, Message ) => {
        Message.reply({ content: `Hello`})
    }
}