const { glob } = require('glob')
const { promisify } = require('util')
const Glob = promisify(glob)


module.exports = async Client => {
    const CMd = Glob(`${process.cwd()}/Commands/**/*.js`)
    ;(await CMd).map((Comamnd) => {
        const Cmd = require(Comamnd)
        if (!Cmd.name) return;
        Client.Command.set(Cmd.name, Cmd)
    })
}